class Pessoa:
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade

    def apresentar(self):
        print(f"👋 Olá, meu nome é {self.nome} e tenho {self.idade} anos.")

class Aluno(Pessoa):
    def __init__(self, nome, idade, curso):
        super().__init__(nome, idade) # Chama o construtor da classe pessoa
        self.curso = curso


    def estudar(self):
        print(f"📚 {self.nome} está estudando {self.curso}.")

        def ensinar(self):
            



class professor(Pessoa):
    def __init__ (self, nome, idade, disciplina):
        super().__init__(nome, idade)
        self.disicplina = disciplina


    def ensinar(self):
        print(f"{self.nome}está ensinando {self.disicplina}.")

class Funcionario(Pessoa)
def __init__(self, nome, idade, setor):

    super().__init__(nome, idade)
        self.setor = setor


    def trabalhar(self):
        print(f"{self.nome}está trabalhando no setor de {self.setor}.")

    p1: Aluno()